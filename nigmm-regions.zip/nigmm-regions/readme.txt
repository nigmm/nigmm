﻿nigmm regions data set (02.11.2015)
-----------------------------------

List of available files
-----------------------

Filename                        Updated
--------                        -------
codes_andorra.txt                10.2015
codes_austria.txt                 2010
codes_belgium.txt                 2010
codes_brazil.txt                 10.2015
codes_bulgaria.txt               10.2015
codes_croatia.txt                 2009
codes_cyprus.txt                 10.2015
codes_czech_republic.txt          2008
codes_denmark.txt                 2007
codes_dominican_republic.txt     10.2015
codes_estonia.txt                10.2015
codes_finland.txt                10.2015
codes_france.txt                  2010
codes_germany.txt                10.2015
codes_germany_1gemeinden.txt     10.2015
codes_germany_2cities.txt        10.2015
codes_greece.txt                  2008
codes_hungary.txt                 2008
codes_iceland.txt                10.2015
codes_ireland.txt                10.2015
codes_italy.txt                   2009
codes_latvia.txt                 10.2015
codes_liechtenstein.txt          10.2015
codes_lithuania.txt              10.2015
codes_luxembourg.txt              2010
codes_malta.txt                  10.2015
codes_monaco.txt                 10.2015
codes_netherlands.txt             2008
codes_norway.txt                 10.2015
codes_poland.txt                  2008
codes_portugal.txt                2006
codes_romania.txt                10.2015
codes_russia.txt                 10.2015
codes_san_marino.txt             10.2015
codes_slovakia.txt                2010
codes_slovenia.txt               10.2015
codes_spain.txt                   2010
codes_sweden.txt                  2010
codes_switzerland.txt             2010
codes_thailand.txt               10.2015
codes_turkey.txt                 10.2015
codes_united_kingdom.txt         10.2015
codes_united_states.txt          10.2015
codes_vatican_city.txt           10.2015

Countries: 42 / Files: 44

Data types:
-----------
    - postcode range:   "00000, 00000 = name" 
    - single code:      "00000 = name"
    - single code+name: "00000; place_name_as_in_csv = name"
    - single name:      "; place_name_as_in_csv = name"
    - pseudolink:       "= name"

Data sources:
-------------
Data sources used for check and update of postcodes and names are:
    - public data available on many local postal company websites
    - search tool on local postal company websites
    - Wikipedia	
Note that:
    - sometimes public data and search tool give different result
    - data is not the same on different by language Wikipedia pages 

Not covered cases:
------------------
    - In many countries the same postcode can be used in several areas. Most of such cases are not handled.
    - In some countries postcode system changed after 2002. Only latest postcode system is used in codes file.
    - In some countries postcode updates are happing constantly. Only latest postcodes are used in codes file.

Disclaimer:
----------- 
There might be mistakes and misspellings.
If you faced a problem with data, then send me information by email or PM at EBTF.
