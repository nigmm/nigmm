nigmm (note info generator mini mod), version 0.041 (06.04.2017)
----------------------------------------------------------------
Copyright (c) 2014-2017, nigmm

This is minimalistic application for generating offline NIG-like style statistics 
from your EBT CSV data files. 
It's NOT replacement for NIG or EBTST tools.

Installation, configuration instructions
----------------------------------------
1. Unzip everything from zip package to the same directory.
   The package consists of the following files:
       nigmm.css
       nigmm.exe
       nigmm.js 
       readme.txt (this file)
2. Windows-version requires Microsoft Visual C++ 2010 Redistributable Package
   (http://www.microsoft.com/en-us/download/details.aspx?id=5555)
3. Download your CSV files.

Proposed directories structure
------------------------------
Below you can find well-working structure for application and data directories: 
   C:/<some_dir>/data          - for csv data files
                /nigmm         - for application
                /nigmm-regions - for regions data files

Operating instructions
----------------------
1. Run nigmm.exe
2. Select notes and hits CSV files
3. (optional) Select directory with user defined regions files.
4. Press 'Create statistics'

   Result of execution: 
       <your_userid>_statictics/ directory 
       debug/ directory 
       nigmm.log
       nigmm.cfg

5. Check generated webpages in your browser

   Note: Javascript is used for adding extra functionality for generated web pages. 
         Your browser might ask to restrict webpage from running scripts. 
         Script can be disabled or removed if needed.   

Available statistics
--------------------
Statistics
    Profile:
        Summary
        Note and hits changes during (current, previous, average) 7 days, month, year
        Top active and inactive periods (notes)    
        Top active and inactive periods (hits)            
        Calendar milestones
        Combo summary
Notes
    Notes by denomination:
        Summary
        Yearly statistics
        First notes
    Notes by series:
        Summary
        Detailed information by note value
        Yearly statistics
        First notes
    Notes by signature:
        Summary
        Detailed information by note value
        Yearly statistics
        New/unknown signatures found
        First notes
    Notes by country:
        Summary
        Detailed information by note value
        Yearly statistics
        First notes
    Notes by printer:
        Summary
        Detailed information by note value
        Yearly statistics
        First notes
    Printcode analysis:
        Lowest and highest printcodes
        Print sheet location bingo
    Notes by combination:
        Summary
        Detailed information by note value
        Yearly statistics
        First notes    
    Serial analysis: 
        Near notes / "Family meeting"
        Serial number analysis: digits, consecutive digits, progression of digits, palindroms
    Huge table
    Travel stats
    Location: country 
        Summary by countries
        Summary by country+locations
        Alphabets of locations
    Location: place
        Summary by locations
        Summary by location+postcode
        Top visited postcode locations
    Date analysis: 
        Summary by year
        Top months
        Top days
        Notes entering date bingo
        Summary by weekday
    Time analysis:
        Summary by hour
        Notes entering time bingos (HH:MM & MM:SS)
    Comments:    
        Top entered note comments
Hits
    Hits summary:
        Hits summary: national/international/moderated, maker/finder, days (all, avg, max), 
                      kms (all, avg, max), speed (min, avg, max)
    Hits by denomination:
        Summary
        Yearly statistics (normal & reversed)
    Hits by series:
        Summary
        Detailed information by note value    
    Hits by signature:
        Summary
        Detailed information by note value    
    Hits by country:
        Summary
        Detailed information by note value    
    Hits by printer:
        Summary
        Detailed information by note value    
    Hits by combination:
        Summary
        Detailed information by note value    
    Location: country 
        Summary by full path
        Summary by country
        Top locations
        Top directions (one way & both ways)
        Top postcodes              
    Hits analysis: 
        Top by most kilometres
        Top by most days
        Latest triple+ hits
        Latest international hits
        Top of lucky, potential an unlucky bundles
        Hits by kms/days bingos (10x10 & 20x20)
        Top partners    
    Date analysis: 
        Summary by year (normal & reversed)
        Top months
        Top days
        Notes entering date bingo
        Summary by weekday
    Time analysis:
        Summary by hour
        Notes entering time bingos (HH:MM & MM:SS)    
    Hit list:
        All normal hits
        Latest moderated hits
Other
    Regions: 
        User defined regions stats
    Custom statistics:
        Summary
        Detailed information 

JS based features on webpages
-----------------------------
* Bingo color pallette changer
* Data sorter by selected column header for 'Detailed information' tables
* First notes toggle (show/hide) for non top rows 

Copyright and licensing information 
-----------------------------------
Disclaimer:

This program is free software. 
You can distribute it freely as long as the package content and files are unmodified.
You may not charge anybody any money for it or use it for profit.

The software is provided "AS IS", and distributed WITHOUT WARRANTY OF ANY KIND. 
The author is NOT RESPONSIBLE FOR ANY DAMAGE that occurs with installation or use of this software. Use at your own risk. 

I can only guarantee that program works with my data on my computer.
Seems to work on Windows XP and Windows 7 (64-bit). 

Of course no support is guaranteed, but the author will attempt to assist with problems.  

Current contact email address is below. Note that it's checked time to time and no qiuck answer promised. 
    nigmm@luukku.com

Credits
-------
To NIG tool and Bobtail for look and feel of original NIG result.

Compiler: MSVC 2010
UI Framework: wxWidgets - http://wxwidgets.org/
Binary packer: UPX - http://upx.sourceforge.net/

Changelog
---------
Version 0.041 (06.04.2017)
    - Added new 50 euro signatures

Version 0.040 (17.01.2017)
    - Only signatures updated.

Version 0.036 (12.11.2016)
    - Only signatures updated.

Version 0.035 (25.09.2016)
    - Only signatures updated.

Version 0.034 (07.09.2016)
    - Search extended: searching by hits data added.
    - Small update for combo on signatures: only simple known signatures are counted

Version 0.033 (07.06.2016)
    - First notes: data extended, format changed from list to table in 5 pages
    - js file updated for first notes show/hide functionality
    - "Combo summary" added to profile page (can be moved later to own page)
    - "Combo" column added to 5 notes and 5 hits detailed tables
    - Bingo result line a bit changed
    - CSS updated: button and link styles, few additions
    - CSS updated: pctline table changed to div

Version 0.032 (12.05.2016)
    - Signatures updated.
    - Minor update on signatures page.
    - Small internal changes here and there.

Version 0.031 (18.03.2016)
    - Only signatures updated.

Version 0.030 (28.01.2016)
    - Only signatures updated.

Version 0.028 (14.12.2015)
    - Set of small updates:
    - Application working directory always changed to directory where the binary is located
      (this seems to be needed for old Win version where "Start in" directory not set by default in shortcuts) 
    - Hits csv file became optional
    - CSS updated with arrows for sorted columns of detailed tables
    - Search UI: notes list max items limit changed from 100 to 10K
      (operations with data list will be slower with big amount of data)
    - External signatures file (signatures-external.csv) loaded automatically during notes/hits data load if it exists
    - Experimenting: offline maps support, requiring nigmm-regions-maps.zip with one Finnish map as example

Version 0.027 (30.11.2015)
    - Added new 20 euro signatures

Version 0.026 (30.10.2015)
    - Serial analysis: palindroms
    - Regions: codes_*.txt file format extended (check more below about file format 2)

Version 0.025 (12.09.2015)
    - Regions processing improved
    - Link to own 'Extras' page added
    - Small config.file change

Version 0.024 (10.08.2015)
    - Support of new Irish postcodes (Eircodes) added: routing key can be used in region files

Version 0.023 (02.08.2015)
    - Regions pages for notes and hits are combined to one list splitted by country name
    - Small columns order change in 'hits by location' tables
    - User defined statictics: UI updated and moved to settings
    - User defined statistics: stats created again in default statistics directory
    - User defined statistics: added sorting to detailed table
    - Small updates

Version 0.022 (31.05.2015)
    - Search UI: save/load search patterns
    - Experimenting: detailed and yearly statistics table sorting added: js file updated
    - Experimenting: regions: most of alphanumerical postcodes (except UK format) should be supported
    - Experimenting with imaging (non-released-yet part, binary size grows)

Version 0.021 (01.04.2015)
    - Many changes in UI
    - Search UI: "regex" operation replaced "contains" operation
    - Profile page created based on two activity pages
    - Top active and inactive periods: by my hitnote enter date (reverted) removed
    - Updates and fixes: css minor update

Version 0.020 (13.02.2015)
    - Datacells with value bigger than 10% of column value are marked by color in detailed, yearly and custom statistics tables.
    - Experimental feature added: signatures export/import
    - Experimental feature added: user defined statictics 
    - Updates and fixes: css minor update

Version 0.017 (30.12.2014)
    - Only signatures updated.

Version 0.016 (27.11.2014)
    - Several long tables output shortened: "Family meeting" shows top list, 
      "Triples+", "International hits" and "Moderated hits" show latest hits.
    - Hit location tables are updated and separated to own page.
    - Both regions statistics separated to own pages.    
    - Bingo color palette enhanced: amount of colors changed from 5 to 7.
    - Bingo palette changer JavaScript added with 3 palettes.    
    - Notes-hits-hitentries matching mechanism updated to work quicker with big amounts of data.    
    - Search UI: "like" operation replaced by "regex" operation, which supports basic regex patterns. 
      Use '.' as placeholder for any character
    - Other updates
    
Version 0.014 (25.10.2014)
    - Added statictics: Yearly tables in several pages, printer sheet location
    - Search UI: new "like" operation uses patterns with '*' as placeholder for any character
    - Shortcode page and texts changed to print code
    - Small updates

Version 0.013 (30.09.2014)
    - Added new 10 euro signatures
    - Experimental & minimal search notes UI
    - Updates and fixes: FamilyMeeting table a bit updated

Version 0.012 (04.07.2014)
    - Added statictics: Serial analysis, Bingo (km/days)
    - Updates and fixes: css minor update
    
Version 0.011 (08.06.2014)
    - Hit Summary added (at Hits Activity page)
    - Alpha release of user defined regions with limitations (check more below)
    - Updates and fixes: css minor update, cfg changed, top20 changed to top10 in many places.

Version 0.003 (22.05.2014)
    - Added links on pages
    - Combined several result pages: Date analysis x 2 
    - 3-buttons UI created
    - Small updates and fixes: including shortcode table    

Version 0.002 (01.05.2014)
    - Added statictics: Travel stats, Short codes (min/max), Alphabets of locations.
    - Updates and fixes: css minor update, correct name for 2nd serie, huge table style. 

Version 0.001 (16.04.2014)
    - Initial and very prototyping version.

Bugs and TODO list
------------------
Still to add some missing "default" statistics.
Change are possible but not planned.

User defined regions (default format)
-------------------------------------
Currently only limited support of user defined regions is available.
    - Supported file names are codes_*.txt
    - Filename shown in generated webpage above the table
    - New mandatory parameter Country added
    - Numerical and most of alphanumerical postcodes should be supported
    - PrintZeros and SubFlag parameters are not supported
    - NMessage is not really used
    - Simplified statistics table
    - Alphabetical sorting inside group/subgroup
    - Note that big amount of data will slow down processing
    - If you faced a problem with it, then send me by email or PM at EBTF:
        image, which show the problem, 
        used regions data file 
        and information about expected result.

Region file format:
---
Country  = country_name_as_in_csv
Group    = text in html format including flag
SubGroup = text in html format including flag
    00000,00000;place_name_as_in_csv = text in html format including flag
---

User defined regions (file format 2)
------------------------------------
The biggest difference from default format is usage of pseudolinks.
    - New mandatory parameter FileFormat with value 2. 
        Must be set first in the file.
    - New pseudolink codes data format added. Pseudolink can point to group or subgroup. 
      Data from the first (!) found group or subgroup with the same text will be used.
        Format: = text
    - Optional parameters are groupped in:
        new parameter 'Parameters' for groups and subgroups,
        extension of text in codes data.
        (check more in example below)
    - Available parameters are:
        For group only:
          glevel  - group level from 1 (max) to 9 (min); default is 9; required for pseudolinks
          disable - not used in calculations
          noshow  - used in calculations, but not shown in result
        For all elements:
          flag    - flag for the element

Real example: codes_finland.txt

Region file format:
---
FileFormat = 2

Country  = country_name_as_in_csv
Group    = text in html
Parameters = glevel = 1; noshow; disable; flag = url
SubGroup = text in html
Parameters = flag = url
    00000,00000;place_name_as_in_csv = text in html; flag = url
    = text in html
---
    
Experimental: offline map support (mapdata)
-------------------------------------------
1. Offline map data located in maps directory of selected regions directory, 
   for example, C:/<some_dir>/nigmm-regions/maps
2. Changes in codes_*.txt file for mapdata support:
   Group = Example map
   Parameters = map = <mapdata_example.txt> 
   00000,00000;place_name_as_in_csv = text in html; mapid = <ID_nn>
3. Mapdata file "mapdata_example.txt" structure:
   Map = <map_image.png>
   MapAreas = <any text at the moment>
   ID_nn = <pointx, pointy> [;<pointx2, pointy2>]
4. Image file "map_image.png" format:
   PNG file
5. Some debug can be done via "Settings->Debug->Mapdata files->Create"

Check more in the real example in nigmm-regions-maps.zip.

Serial number analysis
----------------------
This analysis count how many times requested pattern was found in the given serial.
In all cases substrings of found string are not counted, for example, 
ladder '123' has ladder-substrings '12' and '23' which are definetely not counted.
 
Patterns are:
    Same digits in the row / consecutive digits
    Ladder up / consecutive progression of digits
    Ladder down / consecutive regression of digits
    Palindroms, except consecutive digits, that is actually also palindrom

Analysis example:
    Serial:          __1221______
    Same-in-the-row: ___AA_______
    Ladder up:       __AB________
    Ladder down:     ____BA______
    Palindrom:       __ABBA______
    
Signatures export/import
------------------------
You can export default signatures list and new/unknown signatures list 
based on your data to csv files in application working directory 
by pressing 'Save' button.

You can import own signatures list from csv file to application
by pressing 'Load' button.

   Note: 
   1. Default file names are used, such as:
        signatures-internal.csv
        signatures-newunknown.csv
        signatures-external.csv
   2. External signatures list is used in data processing 
      only if corresponding combination wasn't found in default list. 

User defined statistics
-----------------------
Created used defined / custom statistics report has some differences 
in compare to default statistics report:
1. Sorting done alphabetically
2. No prefilling for known data types 

Combo calculations
------------------
All calculations done based on internal and user-defined-external signature list.
Theoretically possible but not existent combinations will affect resulting values.



