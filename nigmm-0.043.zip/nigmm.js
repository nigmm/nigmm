/**********************************************************************
 *
 *    nigmm.js : valid for versions 0.033- 
 *
 *    Copyright (c) 2014-2017, nigmm
 *
 **********************************************************************/

/**********************************************************************
 *
 *    Commonly used code 
 *
 **********************************************************************/
 
function getThisTableFirstTbody(_el) 
{  
    node = _el.parentNode;
    while ( ( node != null ) && ( node.tagName != "TABLE" ) )
    {
      node = node.parentNode;      
    } 
    
    if ( node == null )
    {
      return null;
    }
    
    tbody = node.querySelector("tbody");    
    
    return tbody;
}
    
/**********************************************************************
 *
 *    All code for Bingo color changer 
 *
 **********************************************************************/
 
// max hcl palettes number (_xx)
var g_maxHclPalettes = 2; 
// style number 
var g_styleCounter   = 0;

function updateCounter() 
{
    g_styleCounter++;
    if ( g_styleCounter > g_maxHclPalettes )
    {
      g_styleCounter = 0;        
    }
}

function counter2String() 
{
    if ( g_styleCounter == 0 )
    {
      return "";
    }
    
    return ("_" + ("00" + g_styleCounter).slice(-2)); 
}

function onBingoPaletteChangerClick() 
{
    var oldCounter = counter2String();
    updateCounter();
    var newCounter = counter2String();
    
    var x = document.querySelectorAll("td[class^=bingo]");
    var re = new RegExp("(bingo\\d)" + oldCounter);
    
    for ( var i = 0; i < x.length; i++ ) 
    { 
      x[i].className = x[i].className.replace(re, "$1" + newCounter);
    }        
}

/**********************************************************************
 *
 *    All code for Table sorting 
 *
 **********************************************************************/

var SORTING_TBODY = "SORTING_TBODY";
var SORTING_ASC   = "SORTING_ASC";
var SORTING_DESC  = "SORTING_DESC";
 
function getConcatenedTextContent(_node) 
{
    var result = "";
    
    if ( _node == null ) 
    {
      return result;
    }
    
    var children = _node.childNodes;
    
    for ( var i = 0; i < children.length; i++ ) 
    {
      var child = children.item(i);
        
      switch ( child.nodeType ) 
      {
        case 1:
          result += getConcatenedTextContent(child);
          break;
        case 3:
          result += child.nodeValue;
          break;
      }
    }
    
    return result;
}

function tableSortRule(_a, _b) 
{
    var a = _a[0];
    var b = _b[0];
    
    //
    var isEmptyA = 0;
    if ( ( a.length == 0 ) || ( a == "-" ) )
    {
      isEmptyA = 1;
    }
    
    var isEmptyB = 0;
    if ( ( b.length == 0 ) || ( b == "-" ) )
    {
      isEmptyB = 1;
    }
    
    if ( ( isEmptyA != 0 ) && ( isEmptyB != 0 ) )
    {
      return 0;
    }
    else if ( isEmptyA != 0 )
    {
      return 1;
    }
    else if ( isEmptyB != 0 )
    {
      return -1;
    }
    
    //
    var anum = parseFloat(a);
    var bnum = parseFloat(b);
    
    if ( ( ! isNaN(anum) ) && ( ! isNaN(bnum) ) )
    {
      // asc: for numbers
      return bnum - anum;
    }
    else
    {
      // desc: for text
      if ( a < b ) return -1;
      if ( a > b ) return 1;
      return 0;    
    }
}

function doTableSort(_el) 
{
    var colnumber = 0;
    var node;
    var tbody;
    var a = new Array();
    
    //
    node = _el;
    while ( (node = node.previousElementSibling) != null )
    {
      colnumber++      
    } 

    //
    tbody = getThisTableFirstTbody(_el);
  
    if ( tbody == null )
    {
      return;
    }
    
    //
    tbody.id = SORTING_TBODY;
    var j = 0;
    
    for ( var i = 0; (node = tbody.getElementsByTagName("tr").item(i)) != null; i++ ) 
    {
      if ( node.parentNode.id == SORTING_TBODY )
      {
        a[j] = new Array();
        a[j][0] = getConcatenedTextContent(node.getElementsByTagName("td").item(colnumber)).trim();
        a[j][1] = node;
          
        j++;
      }        
    }    
    
    tbody.id = "";
    
    //
    if ( _el.id == SORTING_ASC ) 
    {
      a.reverse();
      _el.id = SORTING_DESC;        
    }
    else if ( _el.id == SORTING_DESC )
    {
      a.reverse();
      _el.id = SORTING_ASC;        
    }    
    else
    {
      node = document.getElementById(SORTING_ASC);
      if ( node != null )
      {
        node.id = "";
      }
        
      node = document.getElementById(SORTING_DESC);
      if ( node != null )
      {
        node.id = "";
      }
        
      a.sort(tableSortRule);    
      _el.id = SORTING_ASC;
    }
    
    //
    for ( var i = 0; i < a.length; i++ ) 
    {    
      node = a[i][1];

      var re = new RegExp("(row)\\d");
      node.className = node.className.replace(re, "$1" + (i % 2 + 1));
        
      tbody.appendChild(node);
    }    
}

/**********************************************************************
 *
 *    All code for First notes table show/hide functionality 
 *
 **********************************************************************/
 
var FN_SHOW = "show";
var FN_HIDE = "hide";

function firstNotesToggle(_el) 
{  
    //
    tbody = getThisTableFirstTbody(_el);
    
    if ( tbody == null )
    {
      return;
    }
    
    //
    var x = tbody.querySelectorAll("tr:not([class~=topcell])");

    if ( x.length > 0 )
    {
      if ( _el.innerHTML.search(FN_HIDE) >= 0 )
      {
        for ( var i = 0; i < x.length; i++ ) 
        { 
          x[i].className += " " + FN_HIDE;
        }   
        _el.innerHTML = _el.innerHTML.replace(FN_HIDE, FN_SHOW);
      }
      else if ( _el.innerHTML.search(FN_SHOW) >= 0 )
      {
        for ( var i = 0; i < x.length; i++ ) 
        { 
          x[i].className = x[i].className.replace(" " + FN_HIDE, "");
        } 
        _el.innerHTML = _el.innerHTML.replace(FN_SHOW, FN_HIDE);            
      }
    }     
}

